//******************************AD Detail sender   validation  start Here*****************************//.
$(document).ready(function(e) {
	
	$('#submit_digital').click(function(e) {
		e.preventDefault();
		//alert('hello');
$("#error_msg").css('color','white');
		
				 $website = $('#website').val();
		        $email = $('#email').val();
				$name=$('#name').val();
				$phone=$('#phone').val();
				//$message=$('#message').val();
				
				
				

				//alert($send_me_cpoyad);

				 var emailRegex = new RegExp(/^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$/i);
 			     var valid = emailRegex.test($email);
		

		var regexp = /(ftp|http|https):\/\/(\w+:{0,1}\w*@)?(\S+)(:[0-9]+)?(\/|\/([\w#!:.?+=&%@!\-\/]))?/
        var valid2=regexp.test($phone);
				
                 if($website == "")
				 {
					$('#error_msg').html("Please Enter Website URL");
					$('#website').focus();
				 }


				  else  if($name == "")
				 {
					$('#error_msg').html("Please Enter Your Name");
					$('#name').focus();
				 }
				
				  else  if($email == "")
				 {
					$('#error_msg').html("Please Enter Email Id");
					$('#email').focus();
				 }
				
				else  if(!valid)
				{
					$('#error_msg').html("Please Enter Valid Email Id");
					$('#email').focus();
				 }
				 
				 else if($phone == "")
				 {
					$('#error_msg').html("Please Enter Phone Number  ");
					$('#phone').focus();
				 }

				   else if(isNaN($phone))
				 {
					$('#error_msg').html("Please Enter Phone Number  ");
					$('#phone').focus();
				 }
				 
				
				 
				 else
				{
					$('#error_msg').html(null);
				
				$.ajax({
					type: "POST",
					cache: false,
					url: "send-contact-mail.php",
					data: 'email='+ $email +'&name='+$name +'&phone='+$phone+'&website='+$website,
					success: function(data) {
						//window.location.href='thanks.php';
						$("#error_msg").css('color','green');
						$("#error_msg").html(data);
						$("#name").val(null);
						$("#email").val(null);
						$("#phone").val(null);
						$("#website").val(null);
					}
				});
				
				}
								
	});
});
//******************************end AD Detail validation  ends Here*****************************//.



//******************************AD Detail sender   validation  start Here*****************************//.
$(document).ready(function(e) {
	
	$('#digital_submit').click(function(e) {
		e.preventDefault();
		//alert('hello');
$("#msg_error").css('color','red');
		
				$name=$('#name2').val();
				$email = $('#email2').val();
				$phone=$('#phone2').val();
				$website = $('#website2').val();
				$message=$('#message').val();
				
				
				

				//alert($send_me_cpoyad);

				 var emailRegex = new RegExp(/^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$/i);
 			     var valid = emailRegex.test($email);
		

				 var regexp = /(ftp|http|https):\/\/(\w+:{0,1}\w*@)?(\S+)(:[0-9]+)?(\/|\/([\w#!:.?+=&%@!\-\/]))?/
		         var valid2=regexp.test($phone);
				
                 if($name == "")
				 {
				 	$('#msg_error').html("Please Enter Your Name");
					$('#name2').focus();
				 }
				
				  else  if($email == "")
				 {
					$('#msg_error').html("Please Enter Email Id");
					$('#email2').focus();
				 }
				
				else  if(!valid)
				{
					$('#msg_error').html("Please Enter Valid Email Id");
					$('#email2').focus();
				 }
				 
				 else if($phone == "")
				 {
					$('#msg_error').html("Please Enter Phone Number");
					$('#phone2').focus();
				 }

				   else if(isNaN($phone))
				 {
					$('#msg_error').html("Please Enter Phone Number");
					$('#phone2').focus();
				 }

				 else if($website == "")
				 {
				 	$('#msg_error').html("Please Enter Website URL");
					$('#website2').focus();
				 }
				 
				 else if($message == "")
				 {	
					$('#msg_error').html("Please enter message");
					$('#message').focus();
				 }
				 
				 else
				{
					$('#msg_error').html(null);
				
				$.ajax({
					type: "POST",
					cache: false,
					url: "send-contact-mail2.php",
					data: 'email='+ $email +'&name='+$name +'&phone='+$phone+'&website='+$website +'&message='+$message,
					success: function(data) {

						window.location.href='thanks.php';
						$("#msg_error").css('color','green');
						$("#msg_error").html(data);
						$("#name2").val(null);
						$("#email2").val(null);
						$("#phone2").val(null);
						$("#website2").val(null);
						$("message").val(null);
					}
				});
				
				}
								
	});
});
//******************************end AD Detail validation  ends Here*****************************//.



