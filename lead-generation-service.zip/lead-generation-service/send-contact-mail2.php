
<?php
ob_start();
include_once('common.php');

//$order_det_swewx = $obj->getAnyTableWhereData($obj->getTable("var_installment_payment"),"  and id=4");  

//print_r(unserialize(html_entity_decode($order_det_swewx['no_of_payments'])));
	//echo "hi";	
if(isset($_POST['email']) )
{
	
	//$_POST['email']=trim($_POST['email']);
	
	
	            $name=trim($_POST['name']);
				
				$message=trim($_POST['message']);
				$website=trim($_POST['website']);
			
				
				$email=trim($_POST['email']);
			
				$phone=trim($_POST['phone']);
				
				

		//For sending mail script are written here
	/*$to="niyaz@stws.io, ashwaria@sevenstarwebsolutions.com, bisht4858@gmail.com";*/
	$to="niyaz@stws.io";
	$subject="SEO India Company Contact Query";
	$from="info@seoindiacompany.org";
	// Always set content-type when sending HTML email
$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

// More headers
$headers .= 'From: '.$from . "\r\n";
/*if($send_me_cpoyad==1)
{
$headers .= 'Cc: '.$from . "\r\n";
}*/
	$matter='
	<html>
	<head>
	<title>SEO India Company Contact Query</title>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	</head>
	<body>
	<table>
	
	<tr>
	<td colspan="2"> Dear Admin ,<br> Some one want to be Contact you.</td>
	
	</tr>

	<tr>
	<td>Website:</td>
	<td>'.$website.'</td>
	</tr>
	
	<tr>
	<td>Name:</td>
	<td>'.$name.'</td>
	</tr>
	<tr>
	<td>Email:</td>
	<td>'.$email.'</td>
	</tr>
	<tr>
	<td>Phone:</td>
	<td>'.$phone.'</td>
	</tr>

	<tr>
	<td>Message:</td>
	<td>'.$message.'</td>
	</tr>
	
	</table>
	</body>
	</html>
	';
	$yes=mail($to,$subject,$matter,$headers);
	if($yes)
	{

		?>
		<script type="text/javascript">
			window.location.href="thanks.php";
		</script>
				
		<?php
      /*echo ("<p style='background:#1154d0;padding:35px;font-size:23px;color:#fff;width:500px;margin:0 auto;position:absolute;left:0;right:0;top:15%;z-index:99;text-align: center;line-height: 35px;'>
      	<img src='http://demo17.com/landing-page/seo-india-company/images/success.png' style='max-width:100%;height:auto;display:block;margin:0 auto;'>
      	Your Mail is sent Successfully.<br>Our Team will contact you shorltly
      	<a href='http://demo17.com/landing-page/seo-india-company/index.html' style='display: inline-block;font-size: 17px;text-align: center;background: #fff;color:#01a0e2;padding: 3px 15px;font-weight: 600;border-radius: 30px;margin-top: 15px;'>Back to Website</a>
      	</p>");*/
	}

	else
	{
		echo ("<p style='background:white;padding:50px;font-size:23px;color:#111;width:400px;margin:0 auto;position:absolute;left:0;right:0;top:15%;'>Your Mail is not sent. Please Try Again</p>");
	}
 }
 
 // Join us query

?>

