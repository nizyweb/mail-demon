<!DOCTYPE html>
<html>
<head>
<title>Thank You</title>
<style type="text/css">
.wrapper
{
	margin-top: 5%;
}
.imgs
{
	max-width: 100%;
	height: auto;
	display: block;
	margin: 0 auto;
}
.txt-1
{
	font-size: 60px;font-weight: 900;text-align: center;font-family: montserrat, sans-serif;color: #364049;margin: 10px 0;
}
.txt-2
{
	text-align: center;font-size: 25px;font-family: montserrat, sans-serif;color: #364049;
}
.txt-3
{
	display: block;font-size: 20px;text-align: center;background: #5aaf50;color:#fff;padding: 15px 15px;font-weight: 600;text-decoration: none;font-family: montserrat;width: 15%;margin: 0 auto;
}
</style>
</head>
<body style="background:#f9f9f9;">
<div class="wrapper">
	<img src="images/check-sign.png" class="imgs">
	<h1 class="txt-1">Thank You!</h1>
	<p class="txt-2">Your Mail is sent Successfully. Our Team will contact you shorltly</p>
	<a class="txt-3" href="http://www.seoindiacompany.org/lead-generation-service/">Back to Website</a>
</div>
</body>
</html>